import random
import time

decision = "#"

def loading_animation():
  phases = [".", "..", "...", "...."]
  for _ in range(3):  # Repeat the animation 3 times
    for phase in phases:
        print(f"Game loading{phase}", end='\r')
        time.sleep(0.3)
  print("Game loaded successfully.")

def new_game():
  print("Starting a new game.")
  time.sleep(.4)
  print("What is your name?")
  name = input()
  money = 100
  time.sleep(.2)
  print("Hello, " + name + ". Welcome to the game.")

def load_game():
    global name, money
    try:
        with open("save.txt", "r") as f:
            name = f.readline().strip()
            money = int(f.readline().strip())
            loading_animation()
            print(f"Welcome back, {name}!")
            print(f"You have {money} euros.")
            return True
    except FileNotFoundError:
        print("No save file found.")
        return False
print("Do you want to load your previous game? (yes/no)")
load_choice = input().lower()
if load_choice == 'yes':
    if load_game():
      time.sleep(.4)
      print("Let's continue.")
    else:
      time.sleep(.4)
      print("No previous game found. Starting a new game.")
else:
  new_game()
def save_game():
    data = [
        name,
        str(money),
    ]
    with open("save.txt", "w") as f:
        for item in data:
            f.write(str(item) + "\n")

def play_blackjack():
    global money
    total_dealer = 0
    total_player = 0

    print(f"Ok, {name}, I'll give you two cards")
    time.sleep(.4)

    while money > 0:
        print("How much do you want to bet?")
        bet = int(input())

        while bet > money:
            print("You don't have enough money to bet that amount.")
            print("Enter a bet equal to or less than your available money: ")
            bet = int(input())

        # Deal two cards for the player
        player_cards = []
        for _ in range(2):
            player_cards.append(generate_card())
            time.sleep(1)

        if player_cards[0] == player_cards[1]:
            print("You got a pair! Do you want to split it? (yes/no)")
            split_decision = input().lower()
            if split_decision == 'yes':
                bet *= 2
                player_cards_1 = [player_cards[0], generate_card()]
                player_cards_2 = [player_cards[1], generate_card()]
                print("First hand:", player_cards_1)
                total_player += player_cards_1[0]
                print("Your total for the first hand is", total_player)
                print("Second hand:", player_cards_2)
                total_player = player_cards_2[0]
                print("Your total for the second hand is", total_player)
            else:
                total_player = sum(player_cards)
                print("Your total is", total_player)
        else:
            total_player = sum(player_cards)
            print("Your total is", total_player)

        dealer_cards = []
        for _ in range(1):
            dealer_cards.append(generate_card_dealer())
            time.sleep(1)

        print("The dealer has a", dealer_cards[0], "and a hidden card")
        time.sleep(1)

        second_dealer_card = generate_card_dealer2()
        dealer_cards.append(second_dealer_card)
        total_dealer = sum(dealer_cards)

        while total_player < 21:
            print("Would you like to hit or stand?")
            decision = input()
            if decision == "hit":
                next_card = generate_card()
                player_cards.append(next_card)
                print("You got a", next_card)
                total_player += next_card
                time.sleep(1)
                print("Your total is", total_player)
            else:
                break

        time.sleep(1)
        print("The dealer's hidden card is", dealer_cards[1])
        time.sleep(1)
        print("The dealer has a total of", total_dealer)

        while total_dealer < 17:
            time.sleep(1)
            print("The dealer will hit")
            dealer_next_hand = generate_card_dealer()
            total_dealer += dealer_next_hand
            time.sleep(1)
            print("The dealer has a total of", total_dealer)

        if total_player > 21:
            time.sleep(1)
            print("You have gone bust")
            money = money - bet
            time.sleep(1)
            print("The dealer wins")
            save_game()
        elif total_dealer > 21:
            time.sleep(1)
            print("The dealer has gone bust")
            time.sleep(1)
            print("You win")
            money = money + bet
            save_game()
        elif total_dealer == total_player:
            print("It's a tie")
            save_game()
        elif total_dealer > total_player:
            time.sleep(1)
            print("The dealer wins")
            money = money - bet
            save_game()
        else:
            time.sleep(1)
            print("You win")
            money = money + bet
            save_game()

        print("Your remaining money:", money)

        if money == 0:
            print("You lost all your money and ruined your life.")
            time.sleep(3)
            exit()

        time.sleep(1)
        print("Do you want to play again? (yes/no)")
        play_again = input()
        if play_again.lower() != 'yes':
            exit()

def generate_card_dealer():
    card = random.randint(2, 13)
    if card > 10:
        if card == 11:
            return 10
        elif card == 12:
            return 10
        elif card == 13:
            return 10
    else:
        return card

def generate_card_dealer2():
    card = random.randint(2, 13)
    if card > 10:
        if card == 11:
            return 10
        elif card == 12:
            return 10
        elif card == 13:
            return 10
    else:
        return card

def generate_card():
    card = random.randint(1, 13)
    if card > 10:
        if card == 11:
            print("You got a Jack")
            return 10
        elif card == 12:
            print("You got a Queen")
            return 10
        elif card == 13:
            print("You got a King")
            return 10
    elif card == 1:
        print("You got an Ace")
        return handle_ace()
    else:
        print("You got a", card)
        return card

def handle_ace():
    if input() == "11":
        return 11
    else:
        return 1

play_blackjack()
